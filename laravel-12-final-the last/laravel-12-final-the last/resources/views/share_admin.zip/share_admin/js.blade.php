<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- BEGIN: Page Vendor JS-->
<script src="/assets_admin/vendors/js/ui/jquery.sticky.js"></script>
<script src="/assets_admin/vendors/js/extensions/toastr.min.js"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="/assets_admin/js/core/app-menu.js"></script>
{{-- <script src="/assets_admin/js/core/app.js"></script> --}}
<!-- END: Theme JS-->

